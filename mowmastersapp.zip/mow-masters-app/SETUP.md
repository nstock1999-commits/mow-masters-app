# Mow Masters PWA Setup Guide

## ✅ Project Structure Initialized

Your React/Supabase PWA is now ready for development. Here's what's been set up:

### 📁 Directory Structure

```
mow-masters-app/
├── src/
│   ├── pages/           # Page components
│   │   ├── PhoneAuth.jsx         # SMS-based authentication
│   │   ├── LeadDashboard.jsx      # Team lead management (by status)
│   │   ├── BookingPage.jsx        # Customer booking form
│   │   ├── QuotePage.jsx          # Quote request form
│   │   ├── Dashboard.jsx          # Customer dashboard
│   │   └── NotFound.jsx           # 404 page
│   ├── styles/          # CSS files
│   │   ├── Auth.css
│   │   ├── Dashboard.css
│   │   └── Forms.css
│   ├── lib/             # Business logic
│   │   ├── supabaseClient.js      # Supabase queries + helpers
│   │   └── smsService.js          # SMS abstraction (Twilio/AWS/Custom)
│   ├── context/         # React context
│   │   └── AuthContext.js         # Auth state management
│   ├── App.jsx          # Main app component + routing
│   ├── App.css          # Global styles
│   └── main.jsx         # React entry point
├── supabase/
│   └── migrations/
│       └── 001_init_schema.sql    # Database schema
├── .env.example         # Environment variables template
├── package.json         # Dependencies
├── vite.config.js       # Vite configuration
├── index.html           # HTML entry point
├── manifest.json        # PWA manifest
├── service-worker.js    # Service worker (offline support)
└── README.md
```

---

## 🚀 Quick Start

### 1. Install Dependencies

```bash
cd mow-masters-app
npm install
```

### 2. Set Up Supabase

1. **Create a Supabase project**:
   - Go to https://supabase.com
   - Create a new project
   - Copy your **Project URL** and **Anon Key**

2. **Create database schema**:
   - In Supabase dashboard → SQL Editor
   - Copy & paste the contents of `supabase/migrations/001_init_schema.sql`
   - Execute the SQL

3. **Create environment variables**:
   ```bash
   cp .env.example .env.local
   ```
   - Add your Supabase credentials:
     ```
     VITE_SUPABASE_URL=https://your-project.supabase.co
     VITE_SUPABASE_ANON_KEY=your-anon-key
     ```

### 3. Start Development Server

```bash
npm run dev
```

Your app will be available at `http://localhost:5173`

---

## 📊 Database Schema Overview

### Tables Created:

- **teams** - Your business/organization
- **team_members** - Staff/employees
- **customers** - End customers
- **services** - Service types (mowing, landscaping, etc.)
- **leads** - Potential customers (status: new → contacted → quoted → booked → lost)
- **quotes** - Estimates sent to leads
- **bookings** - Scheduled appointments
- **sms_logs** - SMS message history for auditing

All tables include:
- UUID primary keys
- Timestamps (created_at, updated_at)
- Row-level security (RLS) templates
- Useful indexes for performance

---

## 🔐 Authentication Setup

Currently using **phone SMS login** (as selected):

1. **Customer flow**: Phone SMS → 6-digit code → Name → Logged in
2. **Team member flow**: Same phone auth, different role assignment

### To Connect Twilio SMS:

1. **Create Twilio account**: https://www.twilio.com
2. **Get credentials**:
   - Account SID
   - Auth Token
   - Phone number
3. **Add to `.env.local`**:
   ```
   VITE_SMS_PROVIDER=twilio
   VITE_TWILIO_ACCOUNT_SID=your_sid
   VITE_TWILIO_AUTH_TOKEN=your_token
   VITE_TWILIO_PHONE_NUMBER=+1234567890
   ```

SMS service is abstracted in `src/lib/smsService.js`—easy to swap providers.

---

## 📱 Lead Dashboard Features

**For team members** (`/dashboard`):

✅ **View leads by status**:
- New (just came in)
- Contacted (reached out)
- Quoted (sent estimate)
- Booked (confirmed appointment)
- Lost (didn't convert)

✅ **Quick actions**:
- Move lead through pipeline with one click
- Search by name, phone, email
- View lead details
- See stats at a glance

✅ **Multi-filter support**:
- Filter by status
- Search customers
- Real-time updates from Supabase

---

## 📋 Booking & Quote Pages

### Booking Page (`/booking`)
- Customers enter contact info + address
- Select service type + preferred date/time
- SMS confirmation sent automatically

### Quote Page (`/quote`)
- Customer submits scope of work
- Team gets notified
- Reply with detailed quote via SMS

---

## 🔧 Configuration & Customization

### Update Business Info

Edit `src/pages/PhoneAuth.jsx`:
- Change "Mow Masters" branding
- Update color scheme (`--primary-color`, etc.)

### Add/Remove Services

Services come from database (`services` table). Add them in Supabase:

```sql
INSERT INTO services (team_id, name, description, base_price) VALUES
  ('your-team-id', 'Mowing', 'Weekly lawn mowing', 50.00),
  ('your-team-id', 'Landscaping', 'Design & installation', 200.00),
  ('your-team-id', 'Maintenance', 'Year-round care', 75.00);
```

### Modify Lead Statuses

Edit `src/pages/LeadDashboard.jsx`:
- Change `STATUSES` array
- Update `STATUS_COLORS` to match

---

## 📦 Building for Production

```bash
npm run build
```

Outputs to `dist/` directory. Deploy to:
- **Netlify** (recommended, free HTTPS)
- **Vercel**
- **Your own server**

### Deployment Checklist:

- [ ] Supabase project URL & key in env vars
- [ ] Twilio (or SMS provider) credentials
- [ ] PWA manifest configured
- [ ] Service worker enabled
- [ ] HTTPS enabled (required for PWA)

---

## 🛠️ Next Steps

1. **Populate initial data**:
   - Add your team info to `teams` table
   - Add team members
   - Add services

2. **Test the flow**:
   - Try booking a service
   - Request a quote
   - Login as team member, see leads

3. **Customize SMS templates**:
   - Edit `src/lib/smsService.js`
   - Update message templates to match your brand

4. **Enable PWA features**:
   - App installs on home screen
   - Offline functionality
   - Push notifications (optional)

5. **Connect to your CRM** (optional):
   - Sync leads to Salesforce, HubSpot, etc.
   - Use Supabase webhooks to trigger actions

---

## 📚 Documentation Links

- **Supabase Docs**: https://supabase.com/docs
- **React Docs**: https://react.dev
- **Vite Docs**: https://vitejs.dev
- **Twilio SMS API**: https://www.twilio.com/docs/sms

---

## ❓ Support & Troubleshooting

### SMS not sending?
- Check Twilio credentials in `.env.local`
- Verify phone numbers are in correct format (+1234567890)
- Check SMS logs in Supabase `sms_logs` table

### Supabase connection error?
- Verify URL and anon key in `.env.local`
- Check your Supabase project is active
- Ensure database schema is created

### Build errors?
- Clear node_modules: `rm -rf node_modules && npm install`
- Check Node version: `node --version` (should be 16+)

---

## 🎯 Tasks Remaining

1. **Task #2**: Build booking page ✅ (Done)
2. **Task #3**: Build quote page ✅ (Done)
3. **Task #4**: Build lead dashboard ✅ (Done)
4. **Task #5**: Implement SMS service ✅ (Setup, needs Twilio)
5. **Task #6**: Set up PWA features ✅ (Done)
6. **Task #7**: Deploy to production

---

**Ready to code!** Start with `npm install && npm run dev` 🚀
