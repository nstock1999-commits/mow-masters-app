import React from 'react'
import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      minHeight: '100vh',
      textAlign: 'center',
      backgroundColor: '#ecf0f1'
    }}>
      <h1 style={{ fontSize: '3rem', marginBottom: '1rem' }}>404</h1>
      <p style={{ fontSize: '1.25rem', marginBottom: '2rem', color: '#7f8c8d' }}>
        Page not found
      </p>
      <Link to="/" style={{
        padding: '0.75rem 1.5rem',
        backgroundColor: '#2ecc71',
        color: 'white',
        textDecoration: 'none',
        borderRadius: '6px',
        fontWeight: 600
      }}>
        Go Home
      </Link>
    </div>
  )
}
