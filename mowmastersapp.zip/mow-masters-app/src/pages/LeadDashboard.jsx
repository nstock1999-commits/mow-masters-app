import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { getLeads, updateLeadStatus, getTeamMembers } from '../lib/supabaseClient'
import { useAuth } from '../context/AuthContext'
import '../styles/Dashboard.css'

export default function LeadDashboard() {
  const navigate = useNavigate()
  const { isAuthenticated, teamId, handleLogout, userRole } = useAuth()
  const [leads, setLeads] = useState([])
  const [filteredLeads, setFilteredLeads] = useState([])
  const [teamMembers, setTeamMembers] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedStatus, setSelectedStatus] = useState('new')
  const [searchTerm, setSearchTerm] = useState('')

  const STATUSES = ['new', 'contacted', 'quoted', 'booked', 'lost']
  const STATUS_COLORS = {
    new: '#3498db',
    contacted: '#f39c12',
    quoted: '#9b59b6',
    booked: '#27ae60',
    lost: '#e74c3c'
  }

  useEffect(() => {
    if (!isAuthenticated || userRole !== 'team_member' && userRole !== 'admin') {
      navigate('/auth')
      return
    }

    loadLeads()
  }, [isAuthenticated, teamId, userRole, navigate])

  const loadLeads = async () => {
    setLoading(true)
    try {
      const [leadsData, membersData] = await Promise.all([
        getLeads(teamId || 'default-team'),
        getTeamMembers(teamId || 'default-team')
      ])
      setLeads(leadsData || [])
      setTeamMembers(membersData || [])
      filterAndSort(leadsData || [], selectedStatus, searchTerm)
    } catch (error) {
      toast.error('Failed to load leads')
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  const filterAndSort = (leadsData, status, search) => {
    let filtered = leadsData

    if (status !== 'all') {
      filtered = filtered.filter(l => l.status === status)
    }

    if (search) {
      filtered = filtered.filter(l =>
        `${l.first_name} ${l.last_name}`.toLowerCase().includes(search.toLowerCase()) ||
        l.phone.includes(search) ||
        l.email?.toLowerCase().includes(search.toLowerCase())
      )
    }

    setFilteredLeads(filtered)
  }

  const handleStatusChange = (status) => {
    setSelectedStatus(status)
    filterAndSort(leads, status, searchTerm)
  }

  const handleSearch = (e) => {
    const term = e.target.value
    setSearchTerm(term)
    filterAndSort(leads, selectedStatus, term)
  }

  const handleUpdateStatus = async (leadId, newStatus) => {
    try {
      const updated = await updateLeadStatus(leadId, newStatus)
      setLeads(leads.map(l => l.id === leadId ? { ...l, status: newStatus } : l))
      filterAndSort(leads, selectedStatus, searchTerm)
      toast.success(`Lead moved to ${newStatus}`)
    } catch (error) {
      toast.error('Failed to update lead status')
      console.error(error)
    }
  }

  const statCounts = {
    new: leads.filter(l => l.status === 'new').length,
    contacted: leads.filter(l => l.status === 'contacted').length,
    quoted: leads.filter(l => l.status === 'quoted').length,
    booked: leads.filter(l => l.status === 'booked').length,
    lost: leads.filter(l => l.status === 'lost').length
  }

  if (loading) {
    return (
      <div className="dashboard-container">
        <div className="loading-spinner">Loading leads...</div>
      </div>
    )
  }

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <div className="header-left">
          <h1>🌱 Lead Dashboard</h1>
          <p>Manage your sales pipeline</p>
        </div>
        <div className="header-right">
          <button className="btn-secondary" onClick={() => window.location.reload()}>
            Refresh
          </button>
          <button className="btn-danger" onClick={() => {
            handleLogout()
            navigate('/auth')
          }}>
            Logout
          </button>
        </div>
      </header>

      {/* Stats */}
      <div className="stats-grid">
        {STATUSES.map(status => (
          <div key={status} className="stat-card" style={{ borderLeftColor: STATUS_COLORS[status] }}>
            <div className="stat-value">{statCounts[status]}</div>
            <div className="stat-label" style={{ textTransform: 'capitalize' }}>{status}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="filters-section">
        <div className="search-box">
          <input
            type="text"
            placeholder="Search leads by name, phone, or email..."
            value={searchTerm}
            onChange={handleSearch}
          />
        </div>

        <div className="status-tabs">
          <button
            className={`tab ${selectedStatus === 'all' ? 'active' : ''}`}
            onClick={() => handleStatusChange('all')}
          >
            All Leads
          </button>
          {STATUSES.map(status => (
            <button
              key={status}
              className={`tab ${selectedStatus === status ? 'active' : ''}`}
              onClick={() => handleStatusChange(status)}
              style={{
                borderBottomColor: selectedStatus === status ? STATUS_COLORS[status] : 'transparent'
              }}
            >
              <span
                className="status-dot"
                style={{ backgroundColor: STATUS_COLORS[status] }}
              />
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Leads Table */}
      <div className="leads-section">
        {filteredLeads.length === 0 ? (
          <div className="empty-state">
            <p>No leads found</p>
            {searchTerm && <p className="text-light">Try adjusting your search</p>}
          </div>
        ) : (
          <div className="leads-table-wrapper">
            <table className="leads-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Phone</th>
                  <th>Service</th>
                  <th>Status</th>
                  <th>Assigned To</th>
                  <th>Created</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredLeads.map(lead => (
                  <tr key={lead.id} className="lead-row">
                    <td>
                      <strong>{lead.first_name} {lead.last_name}</strong>
                      {lead.email && <div className="text-light">{lead.email}</div>}
                    </td>
                    <td>{lead.phone}</td>
                    <td>{lead.services?.name || 'Not specified'}</td>
                    <td>
                      <span
                        className="badge"
                        style={{ backgroundColor: STATUS_COLORS[lead.status] }}
                      >
                        {lead.status}
                      </span>
                    </td>
                    <td>{lead.team_members?.name || '-'}</td>
                    <td className="text-light">
                      {new Date(lead.created_at).toLocaleDateString()}
                    </td>
                    <td>
                      <div className="action-buttons">
                        {lead.status !== 'contacted' && (
                          <button
                            className="btn-small btn-secondary"
                            onClick={() => handleUpdateStatus(lead.id, 'contacted')}
                          >
                            Contact
                          </button>
                        )}
                        {lead.status !== 'quoted' && (
                          <button
                            className="btn-small btn-primary"
                            onClick={() => handleUpdateStatus(lead.id, 'quoted')}
                          >
                            Quote
                          </button>
                        )}
                        {lead.status !== 'booked' && (
                          <button
                            className="btn-small btn-primary"
                            onClick={() => handleUpdateStatus(lead.id, 'booked')}
                          >
                            Book
                          </button>
                        )}
                        {lead.status !== 'lost' && lead.status !== 'booked' && (
                          <button
                            className="btn-small btn-danger"
                            onClick={() => handleUpdateStatus(lead.id, 'lost')}
                          >
                            Lost
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="dashboard-footer">
        <p>Showing {filteredLeads.length} of {leads.length} leads</p>
      </div>
    </div>
  )
}
