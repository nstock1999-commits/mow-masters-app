import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { getCustomerByPhone, upsertCustomer } from '../lib/supabaseClient'
import { useAuth } from '../context/AuthContext'
import '../styles/Auth.css'

export default function PhoneAuth() {
  const navigate = useNavigate()
  const { handleLogin } = useAuth()
  const [step, setStep] = useState('phone') // 'phone', 'code', 'name'
  const [phone, setPhone] = useState('')
  const [verificationCode, setVerificationCode] = useState('')
  const [name, setName] = useState('')
  const [loading, setLoading] = useState(false)
  const [userRole, setUserRole] = useState('customer') // 'customer' or 'team_member'

  const formatPhone = (input) => {
    const cleaned = input.replace(/\D/g, '')
    if (cleaned.length <= 3) return cleaned
    if (cleaned.length <= 6) return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3)}`
    return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6, 10)}`
  }

  const handlePhoneSubmit = async (e) => {
    e.preventDefault()
    if (phone.replace(/\D/g, '').length !== 10) {
      toast.error('Please enter a valid 10-digit phone number')
      return
    }

    setLoading(true)
    try {
      // In production, this would send an SMS with a code
      // For now, we'll use a mock code
      const mockCode = Math.random().toString().slice(2, 8).padStart(6, '0')
      console.log(`Mock verification code for ${phone}: ${mockCode}`)
      toast.success('Verification code sent! (Mock: check console)')
      setStep('code')
    } catch (error) {
      toast.error('Failed to send verification code')
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  const handleCodeSubmit = async (e) => {
    e.preventDefault()
    if (verificationCode.length !== 6) {
      toast.error('Please enter a 6-digit code')
      return
    }

    // In production, verify with backend
    // For now, accept any 6-digit code
    setStep('name')
  }

  const handleNameSubmit = async (e) => {
    e.preventDefault()
    if (!name.trim()) {
      toast.error('Please enter your name')
      return
    }

    setLoading(true)
    try {
      const cleanPhone = phone.replace(/\D/g, '')
      const formattedPhone = `+1${cleanPhone}`

      // For team members, would validate against team
      // For customers, create or get existing
      if (userRole === 'customer') {
        const customer = await upsertCustomer(
          'default-team', // In production, get actual team ID
          {
            phone: formattedPhone,
            first_name: name.split(' ')[0],
            last_name: name.split(' ').slice(1).join(' ') || '',
            sms_consent: true
          }
        )

        handleLogin(
          { id: customer.id, phone: formattedPhone, name },
          'default-team',
          'customer'
        )
        navigate('/dashboard')
      } else {
        // Team member auth
        handleLogin(
          { id: 'team-member-id', phone: formattedPhone, name },
          'default-team',
          'team_member'
        )
        navigate('/dashboard')
      }

      toast.success('Welcome!')
    } catch (error) {
      toast.error('Authentication failed')
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="auth-container">
      <div className="auth-card">
        <div className="auth-header">
          <h1>🌱 Mow Masters</h1>
          <p>Book a lawn care service or manage your team</p>
        </div>

        {step === 'phone' && (
          <form onSubmit={handlePhoneSubmit} className="auth-form">
            <h2>Enter Your Phone Number</h2>
            <div className="form-group">
              <label htmlFor="phone">Phone Number</label>
              <input
                id="phone"
                type="tel"
                placeholder="(555) 123-4567"
                value={phone}
                onChange={(e) => setPhone(formatPhone(e.target.value))}
                disabled={loading}
                autoFocus
              />
            </div>

            <div className="form-group">
              <label htmlFor="role">I am a:</label>
              <select
                id="role"
                value={userRole}
                onChange={(e) => setUserRole(e.target.value)}
              >
                <option value="customer">Customer (Book Service)</option>
                <option value="team_member">Team Member (Manage Leads)</option>
              </select>
            </div>

            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? 'Sending...' : 'Send Code'}
            </button>
          </form>
        )}

        {step === 'code' && (
          <form onSubmit={handleCodeSubmit} className="auth-form">
            <h2>Enter Verification Code</h2>
            <p className="text-light">We sent a code to {phone}</p>
            <div className="form-group">
              <label htmlFor="code">6-Digit Code</label>
              <input
                id="code"
                type="text"
                placeholder="000000"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value.slice(0, 6))}
                maxLength="6"
                autoFocus
              />
            </div>

            <button type="submit" className="btn-primary" disabled={loading}>
              Verify
            </button>

            <button
              type="button"
              className="btn-outline"
              onClick={() => setStep('phone')}
              style={{ marginTop: '1rem' }}
            >
              Back
            </button>
          </form>
        )}

        {step === 'name' && (
          <form onSubmit={handleNameSubmit} className="auth-form">
            <h2>What's Your Name?</h2>
            <div className="form-group">
              <label htmlFor="name">Full Name</label>
              <input
                id="name"
                type="text"
                placeholder="John Smith"
                value={name}
                onChange={(e) => setName(e.target.value)}
                disabled={loading}
                autoFocus
              />
            </div>

            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? 'Signing in...' : 'Continue'}
            </button>

            <button
              type="button"
              className="btn-outline"
              onClick={() => setStep('code')}
              style={{ marginTop: '1rem' }}
            >
              Back
            </button>
          </form>
        )}
      </div>

      <div className="auth-footer">
        <p>By continuing, you agree to our Terms of Service and Privacy Policy</p>
      </div>
    </div>
  )
}
