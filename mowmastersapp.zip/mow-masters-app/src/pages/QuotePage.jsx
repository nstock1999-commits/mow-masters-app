import React, { useState } from 'react'
import toast from 'react-hot-toast'
import '../styles/Forms.css'

export default function QuotePage() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    address: '',
    city: '',
    state: '',
    zip: '',
    scopeOfWork: ''
  })

  const [loading, setLoading] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      // In production, this would create a quote in the database
      // and send an SMS with a link to review/accept it

      setSubmitted(true)
      toast.success('Request submitted! We\'ll send you a quote soon.')

      setTimeout(() => {
        setFormData({
          firstName: '',
          lastName: '',
          phone: '',
          email: '',
          address: '',
          city: '',
          state: '',
          zip: '',
          scopeOfWork: ''
        })
        setSubmitted(false)
      }, 3000)
    } catch (error) {
      toast.error('Failed to request quote')
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  if (submitted) {
    return (
      <div className="form-container">
        <div className="success-message">
          <h2>✓ Quote Request Sent!</h2>
          <p>We've received your request and will send you a detailed quote via SMS shortly.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="form-container">
      <div className="form-card">
        <div className="form-header">
          <h1>🌱 Request a Quote</h1>
          <p>Get a free estimate for your lawn care needs</p>
        </div>

        <form onSubmit={handleSubmit} className="form">
          <div className="form-section">
            <h3>Your Information</h3>
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="firstName">First Name *</label>
                <input
                  id="firstName"
                  type="text"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="lastName">Last Name *</label>
                <input
                  id="lastName"
                  type="text"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="phone">Phone Number *</label>
                <input
                  id="phone"
                  type="tel"
                  name="phone"
                  placeholder="(555) 123-4567"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                />
              </div>
            </div>
          </div>

          <div className="form-section">
            <h3>Property Location</h3>
            <div className="form-group">
              <label htmlFor="address">Street Address *</label>
              <input
                id="address"
                type="text"
                name="address"
                value={formData.address}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="city">City *</label>
                <input
                  id="city"
                  type="text"
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="state">State *</label>
                <input
                  id="state"
                  type="text"
                  name="state"
                  maxLength="2"
                  value={formData.state}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="zip">ZIP *</label>
                <input
                  id="zip"
                  type="text"
                  name="zip"
                  value={formData.zip}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
          </div>

          <div className="form-section">
            <h3>What do you need?</h3>
            <div className="form-group">
              <label htmlFor="scopeOfWork">Describe the work you need done *</label>
              <textarea
                id="scopeOfWork"
                name="scopeOfWork"
                rows="6"
                value={formData.scopeOfWork}
                onChange={handleChange}
                placeholder="E.g., Weekly mowing, landscape design, tree trimming, etc."
                required
              />
            </div>
          </div>

          <button
            type="submit"
            className="btn-primary btn-large"
            disabled={loading}
          >
            {loading ? 'Sending...' : 'Request Quote'}
          </button>
        </form>
      </div>
    </div>
  )
}
