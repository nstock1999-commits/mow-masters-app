import React from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import '../styles/Dashboard.css'

export default function Dashboard() {
  const { handleLogout } = useAuth()

  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <div className="header-left">
          <h1>🌱 Mow Masters</h1>
          <p>Welcome to your account</p>
        </div>
        <div className="header-right">
          <button className="btn-danger" onClick={() => {
            handleLogout()
            window.location.href = '/auth'
          }}>
            Logout
          </button>
        </div>
      </header>

      <div className="container">
        <div className="grid grid-2">
          <Link to="/booking" className="card card-link">
            <h3>📅 Book an Appointment</h3>
            <p>Schedule a lawn care service at your convenience</p>
          </Link>

          <Link to="/quote" className="card card-link">
            <h3>💰 Get a Quote</h3>
            <p>Request a free estimate for your project</p>
          </Link>
        </div>
      </div>
    </div>
  )
}
