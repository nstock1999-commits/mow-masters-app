import React, { useState } from 'react'
import toast from 'react-hot-toast'
import { createBooking, createLead, getServices } from '../lib/supabaseClient'
import { sendSMS, SMS_TEMPLATES } from '../lib/smsService'
import '../styles/Forms.css'

export default function BookingPage() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    address: '',
    city: '',
    state: '',
    zip: '',
    serviceType: '',
    scheduledDate: '',
    scheduledTime: '',
    notes: ''
  })

  const [services, setServices] = useState([])
  const [loading, setLoading] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  React.useEffect(() => {
    loadServices()
  }, [])

  const loadServices = async () => {
    try {
      const data = await getServices('default-team')
      setServices(data || [])
    } catch (error) {
      console.error('Failed to load services:', error)
    }
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Create lead
      const lead = await createLead('default-team', {
        first_name: formData.firstName,
        last_name: formData.lastName,
        phone: formData.phone,
        email: formData.email,
        address: formData.address,
        city: formData.city,
        state: formData.state,
        zip: formData.zip,
        service_type_id: formData.serviceType,
        status: 'new',
        notes: formData.notes
      })

      // Create booking if date/time provided
      if (formData.scheduledDate) {
        await createBooking('default-team', {
          customer_id: lead.id,
          service_id: formData.serviceType,
          scheduled_date: formData.scheduledDate,
          scheduled_time_start: formData.scheduledTime,
          address: formData.address,
          city: formData.city,
          state: formData.state,
          zip: formData.zip,
          status: 'scheduled'
        })
      }

      // Send SMS confirmation
      const serviceType = services.find(s => s.id === formData.serviceType)?.name || 'service'
      const message = SMS_TEMPLATES.BOOKING_CONFIRMATION(
        formData.firstName,
        new Date(formData.scheduledDate).toLocaleDateString(),
        formData.scheduledTime,
        serviceType
      )

      await sendSMS(
        'default-team',
        formData.phone,
        message,
        'booking_confirmation',
        lead.id,
        'lead'
      )

      setSubmitted(true)
      toast.success('Booking confirmed! You\'ll receive an SMS confirmation.')
      setFormData({
        firstName: '',
        lastName: '',
        phone: '',
        email: '',
        address: '',
        city: '',
        state: '',
        zip: '',
        serviceType: '',
        scheduledDate: '',
        scheduledTime: '',
        notes: ''
      })

      setTimeout(() => setSubmitted(false), 5000)
    } catch (error) {
      toast.error('Failed to create booking')
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  if (submitted) {
    return (
      <div className="form-container">
        <div className="success-message">
          <h2>✓ Booking Confirmed!</h2>
          <p>We've sent a confirmation SMS to {formData.phone}</p>
          <p>Our team will contact you soon to finalize your appointment.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="form-container">
      <div className="form-card">
        <div className="form-header">
          <h1>🌱 Book a Lawn Care Service</h1>
          <p>Quick and easy scheduling</p>
        </div>

        <form onSubmit={handleSubmit} className="form">
          <div className="form-section">
            <h3>Your Information</h3>
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="firstName">First Name *</label>
                <input
                  id="firstName"
                  type="text"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="lastName">Last Name *</label>
                <input
                  id="lastName"
                  type="text"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="phone">Phone Number *</label>
                <input
                  id="phone"
                  type="tel"
                  name="phone"
                  placeholder="(555) 123-4567"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="email">Email</label>
                <input
                  id="email"
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                />
              </div>
            </div>
          </div>

          <div className="form-section">
            <h3>Service Location</h3>
            <div className="form-group">
              <label htmlFor="address">Street Address *</label>
              <input
                id="address"
                type="text"
                name="address"
                value={formData.address}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="city">City *</label>
                <input
                  id="city"
                  type="text"
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="state">State *</label>
                <input
                  id="state"
                  type="text"
                  name="state"
                  maxLength="2"
                  value={formData.state}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="zip">ZIP *</label>
                <input
                  id="zip"
                  type="text"
                  name="zip"
                  value={formData.zip}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
          </div>

          <div className="form-section">
            <h3>Service Details</h3>
            <div className="form-group">
              <label htmlFor="serviceType">Service Type *</label>
              <select
                id="serviceType"
                name="serviceType"
                value={formData.serviceType}
                onChange={handleChange}
                required
              >
                <option value="">Select a service...</option>
                {services.map(service => (
                  <option key={service.id} value={service.id}>
                    {service.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label htmlFor="scheduledDate">Preferred Date</label>
                <input
                  id="scheduledDate"
                  type="date"
                  name="scheduledDate"
                  value={formData.scheduledDate}
                  onChange={handleChange}
                />
              </div>
              <div className="form-group">
                <label htmlFor="scheduledTime">Preferred Time</label>
                <input
                  id="scheduledTime"
                  type="time"
                  name="scheduledTime"
                  value={formData.scheduledTime}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="notes">Additional Notes</label>
              <textarea
                id="notes"
                name="notes"
                rows="4"
                value={formData.notes}
                onChange={handleChange}
                placeholder="Tell us anything else we should know..."
              />
            </div>
          </div>

          <button
            type="submit"
            className="btn-primary btn-large"
            disabled={loading}
          >
            {loading ? 'Booking...' : 'Book Now'}
          </button>
        </form>
      </div>
    </div>
  )
}
