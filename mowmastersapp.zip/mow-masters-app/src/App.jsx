import React, { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import './App.css'

// Pages
import PhoneAuth from './pages/PhoneAuth'
import Dashboard from './pages/Dashboard'
import BookingPage from './pages/BookingPage'
import QuotePage from './pages/QuotePage'
import LeadDashboard from './pages/LeadDashboard'
import NotFound from './pages/NotFound'

// Context
import { AuthContext } from './context/AuthContext'

function App() {
  const [authState, setAuthState] = useState({
    isAuthenticated: false,
    user: null,
    teamId: null,
    userRole: null,
    loading: true
  })

  useEffect(() => {
    // Check for existing session on mount
    const storedAuth = localStorage.getItem('mow_masters_auth')
    if (storedAuth) {
      try {
        const parsed = JSON.parse(storedAuth)
        setAuthState(prev => ({
          ...prev,
          ...parsed,
          isAuthenticated: true,
          loading: false
        }))
      } catch (e) {
        console.error('Failed to parse auth from storage:', e)
        localStorage.removeItem('mow_masters_auth')
        setAuthState(prev => ({ ...prev, loading: false }))
      }
    } else {
      setAuthState(prev => ({ ...prev, loading: false }))
    }
  }, [])

  const handleLogin = (user, teamId, userRole = 'customer') => {
    const newAuthState = {
      isAuthenticated: true,
      user,
      teamId,
      userRole,
      loading: false
    }
    setAuthState(newAuthState)
    localStorage.setItem('mow_masters_auth', JSON.stringify(newAuthState))
  }

  const handleLogout = () => {
    setAuthState({
      isAuthenticated: false,
      user: null,
      teamId: null,
      userRole: null,
      loading: false
    })
    localStorage.removeItem('mow_masters_auth')
  }

  if (authState.loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <div className="spinner">Loading...</div>
      </div>
    )
  }

  return (
    <AuthContext.Provider value={{ ...authState, handleLogin, handleLogout }}>
      <Router>
        <Toaster position="top-right" />
        <Routes>
          {/* Public Routes */}
          {!authState.isAuthenticated ? (
            <>
              <Route path="/auth" element={<PhoneAuth />} />
              <Route path="/booking" element={<BookingPage />} />
              <Route path="/quote" element={<QuotePage />} />
              <Route path="*" element={<Navigate to="/auth" replace />} />
            </>
          ) : (
            <>
              {/* Authenticated Routes */}
              {authState.userRole === 'team_member' || authState.userRole === 'admin' ? (
                <>
                  <Route path="/dashboard" element={<LeadDashboard />} />
                  <Route path="/leads" element={<LeadDashboard />} />
                  <Route path="*" element={<Navigate to="/dashboard" replace />} />
                </>
              ) : (
                <>
                  <Route path="/dashboard" element={<Dashboard />} />
                  <Route path="/booking" element={<BookingPage />} />
                  <Route path="/quote" element={<QuotePage />} />
                  <Route path="*" element={<Navigate to="/dashboard" replace />} />
                </>
              )}
            </>
          )}
          <Route path="/404" element={<NotFound />} />
        </Routes>
      </Router>
    </AuthContext.Provider>
  )
}

export default App
