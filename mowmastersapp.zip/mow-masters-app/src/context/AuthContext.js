import React from 'react'

export const AuthContext = React.createContext({
  isAuthenticated: false,
  user: null,
  teamId: null,
  userRole: null,
  loading: false,
  handleLogin: () => {},
  handleLogout: () => {}
})

export function useAuth() {
  const context = React.useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within AuthContext provider')
  }
  return context
}
