# 🏗️ Mow Masters Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    CLIENT (React PWA)                            │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐           │
│  │  PhoneAuth   │  │  Booking     │  │  Lead        │           │
│  │  (SMS Login) │  │  Form        │  │  Dashboard   │           │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘           │
│         │                 │                 │                   │
│         └─────────────────┴─────────────────┘                   │
│                         │                                       │
│                  ┌──────▼──────┐                                │
│                  │  AuthContext │                               │
│                  │  (User State)│                               │
│                  └──────┬───────┘                               │
│                         │                                       │
│         ┌───────────────┼───────────────┐                       │
│         │               │               │                       │
│    ┌────▼────┐  ┌──────▼──────┐  ┌────▼─────────┐             │
│    │ Supabase │  │ SMS Service │  │ React Router │             │
│    │ Client   │  │ (Twilio)    │  │              │             │
│    └────┬────┘  └──────┬──────┘  └──────────────┘             │
│         │               │                                       │
└─────────┼───────────────┼──────────────────────────────────────┘
          │               │
          │ HTTPS         │ HTTPS
          │               │
┌─────────▼───────────────▼──────────────────────────────────────┐
│                      BACKEND                                    │
│                                                                  │
│  ┌────────────────────────────────────────┐                    │
│  │     Supabase (PostgreSQL + Auth)       │                    │
│  │                                        │                    │
│  │  ┌──────────┐  ┌──────────┐            │                    │
│  │  │ Teams    │  │ Customers│            │                    │
│  │  └──────────┘  └──────────┘            │                    │
│  │  ┌──────────┐  ┌──────────┐            │                    │
│  │  │ Leads    │  │ Bookings │            │                    │
│  │  └──────────┘  └──────────┘            │                    │
│  │  ┌──────────┐  ┌──────────┐            │                    │
│  │  │ Quotes   │  │ SMS Logs │            │                    │
│  │  └──────────┘  └──────────┘            │                    │
│  │                                        │                    │
│  └────────────────────────────────────────┘                    │
│                                                                  │
│  ┌────────────────────────────────────────┐                    │
│  │     Twilio (SMS Gateway)               │                    │
│  │  • Sends verification codes            │                    │
│  │  • Sends booking confirmations         │                    │
│  │  • Sends quote notifications           │                    │
│  │  • Sends appointment reminders         │                    │
│  └────────────────────────────────────────┘                    │
│                                                                  │
└──────────────────────────────────────────────────────────────┘
```

---

## Data Flow

### 1. Customer Booking Flow

```
Customer                 App                    Supabase              Twilio
   │                     │                         │                   │
   ├─ Enter Phone ───────►│                         │                   │
   │                     │─ Verify Phone ─────────►│                   │
   │                     │                         │                   │
   ├─ Enter Code ───────►│                         │                   │
   │                     │─ Create Customer ──────►│                   │
   │                     │◄──── Customer ID ───────│                   │
   │                     │                         │                   │
   ├─ Fill Booking ─────►│                         │                   │
   │                     │─ Create Booking ───────►│                   │
   │                     │◄─── Booking ID ────────│                   │
   │                     │                         │                   │
   │                     │─ Send SMS ─────────────────────────────────►│
   │◄─── SMS Confirm ────────────────────────────────────────────────│
   │                     │─ Log SMS ──────────────►│                   │
   │                     │                         │                   │
```

### 2. Lead Management Flow (Team)

```
Team Member             App                    Supabase
   │                    │                        │
   ├─ Login SMS ───────►│                        │
   │                    │─ Verify Phone ────────►│
   │◄─ Access ◄────────│                        │
   │                    │                        │
   │◄─ View Leads ◄────│◄──── SELECT ──────────│
   │  (status: new)     │                        │
   │                    │                        │
   ├─ Move to "contacted" ──────────────────────►│
   │                    │─ UPDATE status ───────►│
   │                    │                        │
   ├─ Move to "quoted" ─────────────────────────►│
   │                    │─ UPDATE status ───────►│
   │                    │                        │
   ├─ Move to "booked" ─────────────────────────►│
   │                    │─ UPDATE status ───────►│
   │                    │                        │
```

---

## Component Hierarchy

```
App
├── Router
│   ├── PhoneAuth          # /auth
│   ├── LeadDashboard      # /dashboard (team)
│   ├── BookingPage        # /booking
│   ├── QuotePage          # /quote
│   ├── Dashboard          # /dashboard (customer)
│   └── NotFound           # /404
│
└── AuthContext            # Global auth state
    ├── isAuthenticated
    ├── user
    ├── teamId
    └── userRole (customer | team_member | admin)
```

---

## Database Schema (Simplified)

### Core Tables

```sql
teams
├── id (UUID)
├── name, phone, email
└── address, city, state, zip

team_members
├── id (UUID)
├── team_id (FK)
├── name, phone, email
├── role (admin | manager | team_member)
└── is_active

customers
├── id (UUID)
├── team_id (FK)
├── phone (UNIQUE)
├── first_name, last_name, email
├── address, city, state, zip
└── sms_consent

leads
├── id (UUID)
├── team_id (FK)
├── customer_id (FK, nullable)
├── phone, email, address
├── service_type_id (FK)
├── status (new | contacted | quoted | booked | lost)
├── assigned_to (FK team_member)
└── notes

bookings
├── id (UUID)
├── team_id (FK)
├── customer_id (FK)
├── service_id (FK)
├── scheduled_date, scheduled_time_start/end
├── address, city, state, zip
├── status (scheduled | in_progress | completed | cancelled)
└── assigned_to (FK team_member)

quotes
├── id (UUID)
├── team_id (FK)
├── lead_id (FK)
├── customer_id (FK)
├── service_id (FK)
├── scope_of_work
├── line_items (JSONB)
├── total_amount
├── status (draft | sent | accepted | rejected | expired)
└── valid_until (DATE)

sms_logs
├── id (UUID)
├── team_id (FK)
├── recipient_phone
├── message_body
├── message_type (booking_confirmation | quote_sent | reminder | payment_received)
├── status (pending | sent | failed | delivered)
├── provider (twilio | aws_sns)
└── provider_message_id
```

---

## Authentication Flow (SMS-based)

```
┌─────────────────────────────────┐
│  Customer enters phone number   │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  Generate 6-digit code          │
│  (in real app: via Twilio)      │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  Send SMS to customer           │
│  Log in sms_logs table          │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  Customer receives code         │
│  Enters 6 digits                │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  Verify code matches            │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  Get/Create customer record     │
│  Create auth session            │
│  Store in localStorage          │
└────────────┬────────────────────┘
             │
             ▼
┌─────────────────────────────────┐
│  ✓ Logged in                    │
│  Redirect to /dashboard         │
└─────────────────────────────────┘
```

---

## Lead Status Pipeline

```
         ┌─────────────┐
         │     NEW     │ (fresh inquiries)
         └──────┬──────┘
                │
                ▼
         ┌─────────────────┐
         │   CONTACTED     │ (reached out)
         └──────┬──────────┘
                │
         ┌──────┴──────┐
         │             │
         ▼             ▼
   ┌──────────┐   ┌──────────┐
   │ QUOTED   │   │   LOST   │
   └────┬─────┘   └──────────┘
        │
        ▼
   ┌──────────┐
   │  BOOKED  │ (won)
   └──────────┘
```

---

## SMS Service Abstraction

```
┌─────────────────────────────────┐
│   sendSMS(teamId, phone, msg)   │
└────────────┬────────────────────┘
             │
    ┌────────┴────────┬──────────┐
    │                 │          │
    ▼                 ▼          ▼
┌────────────┐ ┌────────────┐ ┌──────────┐
│  TWILIO    │ │  AWS SNS   │ │  CUSTOM  │
│ (default)  │ │ (fallback) │ │ (own API)│
└────────────┘ └────────────┘ └──────────┘
    │                 │          │
    └─────────────────┴──────────┘
           │
           ▼
    ┌─────────────────────────┐
    │  Log to sms_logs table  │
    │  (audit trail)          │
    └─────────────────────────┘
```

**Benefits**: 
- Easy to switch providers
- No code changes needed
- Complete audit trail
- Fallback option

---

## Key Libraries & Versions

```json
{
  "react": "^18.2.0",
  "react-dom": "^18.2.0",
  "react-router-dom": "^6.20.0",
  "@supabase/supabase-js": "^2.38.0",
  "axios": "^1.6.0",
  "date-fns": "^2.30.0",
  "react-hot-toast": "^2.4.1",
  "vite": "^5.0.0"
}
```

---

## Deployment Architecture

```
┌────────────────────────────────┐
│   GitHub Repository            │
│   (nstock1999-commits/)        │
└──────────────┬─────────────────┘
               │
               ▼
┌────────────────────────────────┐
│   Netlify / Vercel             │
│   • Auto-deploy on push        │
│   • Environment variables      │
│   • HTTPS + SSL                │
└──────────────┬─────────────────┘
               │
       ┌───────┴───────┐
       │               │
       ▼               ▼
   ┌────────┐     ┌──────────┐
   │  CDN   │     │  Built   │
   │        │     │   Dist   │
   └────────┘     └──────────┘
       │               │
       └───────┬───────┘
               │
               ▼
         ┌──────────────┐
         │   Visitors   │
         └──────────────┘
```

---

## Scaling Considerations

### Current Setup (MVP)
- ✅ Single Supabase project
- ✅ Basic Twilio integration
- ✅ localStorage for session

### Future Enhancements
- 🔜 Multi-tenancy (multiple teams/organizations)
- 🔜 WebSocket for real-time updates
- 🔜 Image uploads (Supabase Storage)
- 🔜 Payment processing (Stripe)
- 🔜 Advanced reporting/analytics
- 🔜 Custom branding per team

---

## Security Notes

✅ **Implemented**:
- SMS-based auth (no passwords)
- HTTPS everywhere
- Supabase Row-Level Security templates
- Environment variables for secrets
- CORS configuration

🔒 **Recommended** (before production):
- Enable RLS policies in Supabase
- Implement rate limiting on auth endpoints
- Add CAPTCHA to public forms
- SSL certificate on custom domain
- Regular database backups
- Audit SMS logs for compliance

---

## Monitoring & Logging

```
┌──────────────────────────────────┐
│  App (Client-side errors)        │
│  → Logged to console             │
│  → Optional: Sentry integration  │
└──────────────────────────────────┘

┌──────────────────────────────────┐
│  Supabase (Database queries)     │
│  → Monitored in dashboard        │
│  → Query performance stats       │
└──────────────────────────────────┘

┌──────────────────────────────────┐
│  SMS Logs (sms_logs table)       │
│  → Every SMS logged              │
│  → Status tracking               │
│  → Audit trail                   │
└──────────────────────────────────┘

┌──────────────────────────────────┐
│  Netlify/Vercel Logs             │
│  → Deployment history            │
│  → Build logs                    │
│  → Error tracking                │
└──────────────────────────────────┘
```

---

This architecture is designed for:
- **MVP Speed**: Get running in hours
- **Scalability**: Easy to grow from 10 to 10,000 customers
- **Maintainability**: Clean separation of concerns
- **Flexibility**: Swap components as needed (SMS provider, hosting, etc.)

