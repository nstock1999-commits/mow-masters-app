# 🌱 Mow Masters PWA - Option 2 (Hybrid)

Professional lawn care booking + team management app built with React, Supabase, and PWA.

## Features

### 👥 For Customers
- **SMS-based authentication** - No password friction
- **Easy booking** - Schedule service in seconds
- **Request quotes** - Get fast estimates
- **SMS notifications** - Confirmations & reminders

### 👨‍💼 For Team Members  
- **Lead dashboard** - Organize by status (new → quoted → booked)
- **Quick actions** - Move leads through pipeline
- **Search & filter** - Find customers fast
- **Real-time updates** - See new leads instantly

## Tech Stack

- **Frontend**: React 18 + React Router
- **Backend**: Supabase (PostgreSQL + Auth)
- **SMS**: Twilio (abstracted, easily swappable)
- **Build**: Vite
- **PWA**: Service worker + manifest

## Setup

```bash
# Install
npm install

# Configure
cp .env.example .env.local
# Add Supabase URL & Anon Key

# Run
npm run dev
```

See [SETUP.md](./SETUP.md) for detailed instructions.

## Project Structure

```
src/
├── pages/          # Page components
├── styles/         # CSS
├── lib/            # Business logic (Supabase, SMS)
├── context/        # State (AuthContext)
└── App.jsx         # Main app + routing
```

## Pages

| Page | Route | User |
|------|-------|------|
| Phone Auth | `/auth` | Both |
| Dashboard | `/dashboard` | Customer |
| Lead Dashboard | `/dashboard` | Team |
| Booking | `/booking` | Customer |
| Quote | `/quote` | Customer |

## Database Schema

- `teams` - Business/org
- `team_members` - Staff  
- `customers` - Clients
- `services` - Service types
- `leads` - Potential customers (status pipeline)
- `quotes` - Estimates
- `bookings` - Appointments
- `sms_logs` - Message history

[Full schema in `supabase/migrations/001_init_schema.sql`]

## SMS Setup

Using **Twilio** by default (abstracted in `src/lib/smsService.js`):

1. Create Twilio account: https://twilio.com
2. Get Account SID, Auth Token, Phone Number
3. Add to `.env.local`:
   ```
   VITE_SMS_PROVIDER=twilio
   VITE_TWILIO_ACCOUNT_SID=...
   VITE_TWILIO_AUTH_TOKEN=...
   VITE_TWILIO_PHONE_NUMBER=+1...
   ```

Easy to swap for AWS SNS or custom backend.

## Build & Deploy

```bash
npm run build
```

Deploy to:
- **Netlify** (recommended)
- **Vercel**
- **Your server** (with HTTPS)

## Configuration

### Colors
Edit CSS variables in `src/App.css`:
```css
--primary-color: #2ecc71;
--primary-dark: #27ae60;
```

### Services
Add to Supabase `services` table or UI.

### Branding
Update in `src/pages/PhoneAuth.jsx` and `src/pages/LeadDashboard.jsx`.

## Status Pipeline

Leads flow through:
1. **new** - Just came in
2. **contacted** - Reached out
3. **quoted** - Sent estimate  
4. **booked** - Confirmed
5. **lost** - Didn't convert

## PWA Features

✅ Install to home screen  
✅ Offline support (service worker)  
✅ Fast load times (Vite)  
✅ Mobile-optimized  

## Documentation

- [Setup Guide](./SETUP.md)
- [Supabase Docs](https://supabase.com/docs)
- [React Router](https://reactrouter.com)
- [Twilio SMS](https://www.twilio.com/docs/sms)

## Troubleshooting

**SMS not working?**
- Verify Twilio credentials
- Check phone number format (+1234567890)

**Supabase errors?**
- Verify URL and anon key
- Check schema is created

**Build fails?**
- `npm install` from scratch
- Check Node 16+

## Next Steps

1. Run `npm install && npm run dev`
2. Set up Supabase project
3. Add Twilio credentials
4. Populate initial data
5. Customize branding
6. Deploy!

---

Built with ❤️ for lawn care pros. [Edit branding as needed for The Bell System.]
